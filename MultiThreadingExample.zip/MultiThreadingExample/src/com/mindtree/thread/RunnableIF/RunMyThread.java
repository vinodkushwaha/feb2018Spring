package com.mindtree.thread.RunnableIF;

public class RunMyThread {

	public static void main(String a[]) {
		System.out.println("Starting Main Thread...");
		MyRunnableThread mrt = new MyRunnableThread();
		
		Thread t = new Thread(mrt);
		t.start();
		
		System.out.println("End of Main Thread...");
		//mrt.run(); //method call
	}

}
