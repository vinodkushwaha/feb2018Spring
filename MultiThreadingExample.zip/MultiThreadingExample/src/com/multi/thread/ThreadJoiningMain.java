package com.multi.thread;

//Java program to explain the
//concept of joining a thread.

//Creating thread by creating the
//objects of that class
class ThreadJoiningMain {
	public static void main(String[] args) {

		// creating two threads
		ThreadJoining t1 = new ThreadJoining("Thread1");
		ThreadJoining t2 = new ThreadJoining("Thread2");
		ThreadJoining t3 = new ThreadJoining("Thread3");

		// thread t1 starts
		t1.start();

		// starts second thread after when
		// first thread t1 is died.
		try {
			System.out.println("Current Threadt1: "
					+ Thread.currentThread().getName());
			t1.join();
		}

		catch (Exception ex) {
			System.out.println("Exception has " + "been caught" + ex);
		}

		// t2 starts
		t2.start();

		// starts t3 after when thread t2 is died.
		try {
			System.out.println("Current Thread t2: "
					+ Thread.currentThread().getName());
			t2.join();
		}

		catch (Exception ex) {
			System.out.println("Exception has been" + " caught" + ex);
		}
		t3.start();
		System.out.println("Current Threadt3: "
				+ Thread.currentThread().getName());
		
		/*try {
			t3.join();
			System.out.println("Current Thread: "
					+ Thread.currentThread().getName());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
}
