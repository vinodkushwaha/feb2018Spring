package com.multi.thread;

//Java program to explain the
//concept of joining a thread.

//Creating thread by creating the
//objects of that class
class ThreadJoining extends Thread {
	
	ThreadJoining(String id){
		super(id);
	}
	@Override
	public void run() {
		for (int i = 0; i < 2; i++) {
			try {
				//Thread.sleep(500);
				System.out.println("Current Thread: "
						+ Thread.currentThread().getName() + ":" +i );
			}

			catch (Exception ex) {
				System.out.println("Exception has" + " been caught" + ex);
			}
			//System.out.println(i);
		}
	}
}
