package com.multi.thread;

public class CallingWaitFromMain {

	public static void main(String[] args) {
		Object o = new Object(); 
		try {
			o.wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

/*Exception in thread "main" java.lang.IllegalMonitorStateException
at java.lang.Object.wait(Native Method)
at java.lang.Object.wait(Object.java:502)
at com.multi.thread.CallingWaitFromMain.main(CallingWaitFromMain.java:8)*/

