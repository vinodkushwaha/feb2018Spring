package com.multi.thread;

public class SequenceDisplayWithIncrementCounter {

	/**
	 * devinline.com
	 */
	
	static boolean one = true;
	static boolean two = false;
	static boolean three = false;
	 static Object monitor = new Object(); // to acquire lock no other use of that
	static int count = 1;

	public static void main(String[] args) {
		Thread t1 = new Thread(new SequenceDisplayImpl(1));
		Thread t2 = new Thread(new SequenceDisplayImpl(2));
		Thread t3 = new Thread(new SequenceDisplayImpl(3));
		t1.start();
		t2.start();
		t3.start();
		System.out.println(t1.isAlive() + "::" + t2.isAlive() + "::"
				+ t3.isAlive() + "::"+ Thread.currentThread().isAlive());

	}

	    static class SequenceDisplayImpl implements Runnable {
		int threadId;
		
  		 SequenceDisplayImpl(int threadId) {
			this.threadId = threadId;
		}

		@Override
		public void run() {
			print();
		}

		private void print() {
			try {
				synchronized (monitor) {
					while (count < 10) {
						//System.out.println("checking ThreadId::" + threadId);
						 Thread.sleep(200);
						if (1 == threadId) {
							if (!one) {
								monitor.wait();
							} else {
								System.out.print("Thread " + threadId + ":"
										+ count++ + "\n");
								one = false;
								two = true;
								three = false;
								monitor.notifyAll();
							}
						}
						if (2 == threadId) {
							if (!two) {
								monitor.wait();
							} else {
								System.out.print("Thread " + threadId + ":"
										+ count++ + "\n");
								one = false;
								two = false;
								three = true;
								monitor.notifyAll();
							}
						}
						if (3 == threadId) {
							if (!three) {
								monitor.wait();
							} else {
								System.out.print("Thread " + threadId + ":"
										+ count++ + "\n");
								one = true;
								two = false;
								three = false;
								monitor.notifyAll();
							}
						}
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

	}

}