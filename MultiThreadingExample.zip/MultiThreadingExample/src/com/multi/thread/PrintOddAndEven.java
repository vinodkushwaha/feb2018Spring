package com.multi.thread;

/*One of the basic question asked in Java interview to check basic understanding of inter thread 
 communication and related threading construct.
 In this post we are using synchronisation block and wait()/notify() to
 print even/odd numbers by two different threads. */
public class PrintOddAndEven {

	/**
	 * devinline.com
	 */
	static volatile int counter = 1;
	static Object object = new Object();// Monitor

	public static void main(String[] args) {
		Thread tEven = new Thread(new EvenProducer(), "Even thread");
		Thread tOdd = new Thread(new OddProducer(), "Odd thread");
		tEven.start();
		tOdd.start();
	//	tOdd.start();// java.lang.IllegalThreadStateException
	}

	static class EvenProducer implements Runnable {
		
		public void run() {
			
			synchronized (object) {
				while (counter < 10) {
					if (counter % 2 == 0) {
						System.out.println(Thread.currentThread().getName()
								+ " produced " + counter);
						counter++;
						object.notify();
						//The java.lang.Object.notify() wakes up a single thread that is waiting on this object's monitor.
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					} else {
						try {
							object.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
	}

	static class OddProducer implements Runnable {
		public void run() {
			synchronized (object) {
				while (counter < 10) {
					if (counter % 2 != 0) {
						System.out.println(Thread.currentThread().getName()
								+ " produced " + counter);
						counter++;
						object.notify();
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					} else {
						try {
							object.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
	}
}
