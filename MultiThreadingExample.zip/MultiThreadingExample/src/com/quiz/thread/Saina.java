package com.quiz.thread;

//What is the output of the following program? --good question

public class Saina implements Runnable {
	MyClassA a = new MyClassA();
	MyClassB b = new MyClassB();

	public Saina() {
		Thread mainThread = new Thread(this, "Main");
		mainThread.start(); //run method not getting call here
		a.foo(b);
	}

	public void run() {
		b.foo(a);
	}

	public static void main(String arg[]) {
		new Saina();
		/*  
		 * to call run method of saina class
		  Thread thread = new Thread(new Saina(),"main");
		  thread.start();*/
		System.out.println("Successfully Completed");
	}
}

class MyClassA {
	synchronized void foo(MyClassB b) {
	//	System.out.println("Class A foo call \n");
		String name = Thread.currentThread().getName();
		System.out.println(name + " in A");
		try {
			Thread.sleep(100);
		} catch (Exception e) {
		}
		b.bMethod();
	}

	synchronized void aMethod() {
		System.out.println("a method");
	}
}

class MyClassB {
	synchronized void foo(MyClassA a) {
	//	System.out.println("Class B foo call \n");
		String name = Thread.currentThread().getName();
		System.out.println(name + " in B");
		try {
			Thread.sleep(100);
		} catch (Exception e) {
		}
		a.aMethod();
	}

	synchronized void bMethod() {
		System.out.println("b method");
	}
}
