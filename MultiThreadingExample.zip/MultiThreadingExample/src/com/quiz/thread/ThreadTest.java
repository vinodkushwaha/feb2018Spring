package com.quiz.thread;

//What is the output of the following program?

public class ThreadTest implements Runnable {
    public static void main(String[] args) {
        Thread thread = new Thread(new ThreadTest());
        
        //Scenario1
      //  thread.run(); // LINE A  o/p:  246810
      //Scenario2
        thread.start(); //  o/p:  246810
        
      //Scenario3
        thread.start(); //  o/p:  246810
        thread.start(); //  o/p:   246810java.lang.IllegalThreadStateException
     
    }
    @Override
    public void run() {
        for (int i = 2; i <= 10; i = i + 2) {
            System.out.print(i);
        }
    }
}