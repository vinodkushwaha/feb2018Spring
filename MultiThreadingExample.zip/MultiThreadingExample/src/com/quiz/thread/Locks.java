package com.quiz.thread;

//What is the output of the following program?

public class Locks implements Runnable {
	@Override
	public void run() {
		int i = 0;
		;
		while (i < 2) {
			System.out.print("Hai");
			i++;
		}
	}

	public static void main(String... h) {
		Locks locks = new Locks();
		//Thread lock = new Thread(locks);
		locks.start(); //compiler error simple overriding concept and public class Locks extends Runnable wil work fine
		locks.run();//works fine
	}
}
